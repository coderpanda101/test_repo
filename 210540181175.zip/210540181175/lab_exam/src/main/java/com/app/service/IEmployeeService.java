package com.app.service;

import com.app.pojos.Employee;

public interface IEmployeeService {

	 String addEmployee(Employee empDetails, int deptId);
	
}
