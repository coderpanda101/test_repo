package com.app.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import com.app.pojos.Department;

import com.app.service.IDepartmentService;

/**
 * 
 * @author Atharva
 *
 */

@Controller
@RequestMapping("/department")
public class DepartmentController {
	
	@Autowired
	private IDepartmentService departmentServ;
	
	

	public DepartmentController() {
		System.out.println("in dept. cont.");
	}
	
	@GetMapping("/list")
	public String showDepartmentList(Department dept,HttpSession session) {
		System.out.println("In  show department....");
		System.out.println(dept);
		List<Department> deps=  new ArrayList<>();
		deps =departmentServ.getAllDepartment();
		session.setAttribute("dept_list", deps);
		return "/department/list";
	}
	
	@PostMapping("/list")
	public String processDepartmentList(Department dept,HttpSession session,Model modelMap) {
		System.out.println("In  show process department...");
		System.out.println(dept);
		List<Department> deps=  new ArrayList<>();
		deps =departmentServ.getAllDepartment();
		session.setAttribute("dept_list", deps);
		return "redirect:/department/hire";
	}
	
}
