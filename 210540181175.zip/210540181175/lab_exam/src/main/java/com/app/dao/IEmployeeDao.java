package com.app.dao;

import com.app.pojos.Employee;

public interface IEmployeeDao {

	String addEmployee(Employee empDetails, int deptId);
	
}
