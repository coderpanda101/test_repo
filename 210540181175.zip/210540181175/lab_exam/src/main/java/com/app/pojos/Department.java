package com.app.pojos;

import java.util.ArrayList; 
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

/**
 * 
 * @author Atharva
 *
 */

@Entity
@Table(name = "department_tbl")
public class Department extends BaseEntity {

	@Column(name = "dept_name", length = 20, unique = true)
	@NotBlank(message = "Cannot be kept blank")
	private String deptName;
	
	@Column(length = 20)
	@NotBlank(message = "Cannot be kept blank")
	private String location;
	
	@Column()
	private int strength;
	
	@OneToMany(mappedBy = "selectedDepartment", cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
	List<Employee> empList = new ArrayList<Employee>();
	
	public Department() {
		System.out.println("in defConstructor of Department**********");
	}

	public Department(@NotBlank(message = "Cannot be kept blank") String deptName,
			@NotBlank(message = "Cannot be kept blank") String location, int strength) {
		super();
		this.deptName = deptName;
		this.location = location;
		this.strength = strength;
		System.out.println("in paramConstructor of Department*********");
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public int getStrength() {
		return strength;
	}

	public void setStrength(int strength) {
		this.strength = strength;
	}

	public List<Employee> getEmpList() {
		return empList;
	}

	public void setEmpList(List<Employee> empList) {
		this.empList = empList;
	}
	
	// helper methods
	public void addEmployee(Employee employee) {
		empList.add(employee);
		employee.setSelectedDepartment(this);
	}
	public void remEmployee(Employee employee) {
		empList.remove(employee);
		employee.setSelectedDepartment(null);
	}

	@Override
	public String toString() {
		return "Department [deptName=" + deptName + ", location=" + location + ", strength=" + strength + "]";
	}
	
	
	
	
}
