package com.app.pojos;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Past;

import org.springframework.format.annotation.DateTimeFormat;

/**
 * 
 * @author Atharva
 *
 */

@Entity
@Table(name = "emp_tbl")
public class Employee extends BaseEntity {

	@Column(length = 20)
	@NotBlank(message = "Name cannot be blank...")
	private String name;

	@Column(length = 20, unique = true)
	@NotBlank(message = "Email must be provided...")
	@Email
	private String email;
	
	@Column()
	private double salary;
	
	@Column
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@Past(message = "Cannot travel to future....")
	private LocalDate dob;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "dept_id")
	private Department selectedDepartment;
	
	public Employee() {
		System.out.println("in defConstructor of Employee*****");
	}

	public Employee(@NotBlank(message = "Name cannot be blank...") String name,
			@NotBlank(message = "Email must be provided...") @Email String email, double salary,
			@Past(message = "Cannot travel to future....") LocalDate dob) {
		super();
		this.name = name;
		this.email = email;
		this.salary = salary;
		this.dob = dob;
		System.out.println("in paramContructor of Employee********");
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public Department getSelectedDepartment() {
		return selectedDepartment;
	}

	public void setSelectedDepartment(Department selectedDepartment) {
		this.selectedDepartment = selectedDepartment;
	}

	@Override
	public String toString() {
		return "Employee [name=" + name + ", email=" + email + ", salary=" + salary + ", dob=" + dob + "]";
	}
	
	
	
	
	
	
	
}
