package com.app.controller;

import java.time.LocalDateTime;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * 
 * @author Atharva
 *
 */

@Controller
public class HomePageController {

	public HomePageController() {
		System.out.println("in controller HomePageController...........");
	}
	
	@GetMapping("/")
	public String showIndexPage(Model map) {
		System.out.println("in home controller showIndexPage()........");
		
		map.addAttribute("time_stamp", LocalDateTime.now());
		
		return "/index";
	}
	
}
